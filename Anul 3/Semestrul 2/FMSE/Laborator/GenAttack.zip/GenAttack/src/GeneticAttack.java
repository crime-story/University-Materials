import java.util.*;

public class GeneticAttack {
    private static final String TARGET_STRING = "helloworld";
    private static final int POPULATION_SIZE = 100;
    private static final double MUTATION_RATE = 0.01;



    public static void main(String[] args) {
        String[] population = generatePopulation(POPULATION_SIZE);
        Random random = new Random();

        int generation = 0;
        while (true) {

            double[] fitnessScores = new double[POPULATION_SIZE];
            for (int i = 0; i < POPULATION_SIZE; i++) {
                fitnessScores[i] = evaluateFitness(population[i]);
                if (fitnessScores[i] == 1.0) {
                    System.out.println("Found solution: " + population[i] + " in generation " + generation);
                    return;
                }
            }

            double maxScore = -1;
            String bestString = "";
            for (int i = 0; i < POPULATION_SIZE; i++) {
                if (fitnessScores[i] > maxScore) {
                    maxScore = fitnessScores[i];
                    bestString = population[i];
                }
            }
            System.out.println("Generation " + generation + ": " + bestString);

            String[] newPopulation = new String[POPULATION_SIZE];
            for (int i = 0; i < POPULATION_SIZE; i++) {
                String parent1 = selectParent(population, fitnessScores, random);
                String parent2 = selectParent(population, fitnessScores, random);
                String child = crossover(parent1, parent2, random);
                newPopulation[i] = mutate(child, MUTATION_RATE, random);
            }
            population = newPopulation;

            generation++;

        }
    }

    private static String[] generatePopulation(int size) {
        String[] population = new String[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            StringBuilder builder = new StringBuilder();
            for (int j = 0; j < TARGET_STRING.length(); j++) {
                builder.append((char) (random.nextInt(26) + 'a'));
            }
            population[i] = builder.toString();
        }
        return population;
    }

    private static double evaluateFitness(String string) {
        int score = 0;
        for (int i = 0; i < TARGET_STRING.length(); i++) {
            if (string.charAt(i) == TARGET_STRING.charAt(i)) {
                score++;
            }
        }
        return (double) score / TARGET_STRING.length();
    }

    private static String selectParent(String[] population, double[] fitnessScores, Random random) {
        double totalFitness = 0;
        for (double fitness : fitnessScores) {
            totalFitness += fitness;
        }
        double randomValue = random.nextDouble() * totalFitness;

        double sum = 0;
        for (int i = 0; i < POPULATION_SIZE; i++) {
            sum += fitnessScores[i];
            if (sum > randomValue) {
                return population[i];
            }
        }

        return population[POPULATION_SIZE - 1];
    }
    private static String crossover(String parent1, String parent2, Random random) {
        int crossoverPoint = random.nextInt(TARGET_STRING.length());
        return parent1.substring(0, crossoverPoint) + parent2.substring(crossoverPoint);
    }

    private static String mutate(String string, double mutationRate, Random random) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < TARGET_STRING.length(); i++) {
            if (random.nextDouble() < mutationRate) {
                builder.append((char) (random.nextInt(26) + 'a'));
            } else {
                builder.append(string.charAt(i));
            }
        }
        return builder.toString();
    }
}
