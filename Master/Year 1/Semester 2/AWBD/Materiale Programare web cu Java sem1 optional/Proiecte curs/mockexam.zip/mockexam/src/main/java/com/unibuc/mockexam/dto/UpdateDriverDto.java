package com.unibuc.mockexam.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class UpdateDriverDto extends CreateDriverDto {

    @NotNull
    private Long id;

    public UpdateDriverDto() {
    }

    public UpdateDriverDto(Long id) {
        this.id = id;
    }

    public UpdateDriverDto(String name, String email, String city, Long id) {
        super(name, email, city);
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
