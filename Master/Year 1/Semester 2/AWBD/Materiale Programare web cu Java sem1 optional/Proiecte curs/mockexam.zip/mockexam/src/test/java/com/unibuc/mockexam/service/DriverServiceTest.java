package com.unibuc.mockexam.service;

import com.unibuc.mockexam.exception.DriverAlreadyExistsException;
import com.unibuc.mockexam.model.Driver;
import com.unibuc.mockexam.repository.DriverRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DriverServiceTest {

    @InjectMocks
    private DriverService driverService;

    @Mock
    private DriverRepository driverRepository;

    @Test
    void create() {
        Driver driver = new Driver(null, "John", "john@gmail.com", "Bucharest");

        when(driverRepository.findByEmail(driver.getEmail()))
                .thenReturn(Optional.empty());
        Driver createdDriver = new Driver(1L, "John", "john@gmail.com", "Bucharest");
        when(driverRepository.save(driver))
            .thenReturn(createdDriver);

        Driver resultedDriver = driverService.create(driver);

        assertNotNull(resultedDriver);
        assertEquals(createdDriver.getId(), resultedDriver.getId());
        assertEquals(createdDriver.getEmail(), resultedDriver.getEmail());
        assertEquals(createdDriver.getName(), resultedDriver.getName());
        assertEquals(createdDriver.getCity(), resultedDriver.getCity());
    }

    @Test
    void whenAnotherDriverWithSameEmailExists_create_throwsException() {
        Driver driver = new Driver(null, "John", "john@gmail.com", "Bucharest");

        when(driverRepository.findByEmail(driver.getEmail()))
                .thenReturn(Optional.of(mock(Driver.class)));

        DriverAlreadyExistsException exception =
                assertThrows(DriverAlreadyExistsException.class,
                        () -> driverService.create(driver));

        assertEquals("Driver already exists", exception.getMessage());
        verify(driverRepository, times(0)).save(driver);
    }

    @Test
    void update() {
        Driver driver = new Driver(1L, "John", "john@gmail.com", "Bucharest");

        when(driverRepository.findByEmailAndIdNot(driver.getEmail(), driver.getId()))
                .thenReturn(Optional.empty());
        Driver updatedDriver = new Driver(1L, "John", "john@gmail.com", "Bucharest");
        when(driverRepository.save(driver))
                .thenReturn(updatedDriver);

        Driver resultedDriver = driverService.update(driver);

        assertNotNull(resultedDriver);
        assertEquals(updatedDriver.getId(), resultedDriver.getId());
        assertEquals(updatedDriver.getEmail(), resultedDriver.getEmail());
        assertEquals(updatedDriver.getName(), resultedDriver.getName());
        assertEquals(updatedDriver.getCity(), resultedDriver.getCity());
    }

    @Test
    void whenAnotherDriverWithSameEmailExists_update_throwsException() {
        Driver driverToBeUpdated = new Driver(1L, "John", "john@gmail.com", "Bucharest");
        Driver otherDriver = new Driver(2L, "Jonathan", "john@gmail.com", "London");

        when(driverRepository.findByEmailAndIdNot(driverToBeUpdated.getEmail(), driverToBeUpdated.getId()))
                .thenReturn(Optional.of(otherDriver));

        DriverAlreadyExistsException exception =
                assertThrows(DriverAlreadyExistsException.class,
                        () -> driverService.update(driverToBeUpdated));

        assertEquals("Another driver has the same email.", exception.getMessage());
        verify(driverRepository, times(0)).save(driverToBeUpdated);
    }

    @Test
    void whenNameAndCityAreNull_findBy_returnsAllDrivers() {
        List<Driver> allDrivers = getDrivers();
        when(driverRepository.findAll()).thenReturn(allDrivers);

        List<Driver> result = driverService.findBy(null, null);

        assertNotNull(result);
        assertEquals(4, result.size());
        assertEquals(allDrivers.get(0).getId(), result.get(0).getId());
        assertEquals(allDrivers.get(1).getId(), result.get(1).getId());
        assertEquals(allDrivers.get(2).getId(), result.get(2).getId());
        assertEquals(allDrivers.get(3).getId(), result.get(3).getId());

        verify(driverRepository, times(0)).findByCity(anyString());
        verify(driverRepository, times(0)).findByName(anyString());
        verify(driverRepository, times(0)).findByNameAndCity(anyString(), anyString());
    }

    @Test
    void whenNameAndCityAreEmpty_findBy_returnsAllDrivers() {
        List<Driver> allDrivers = getDrivers();
        when(driverRepository.findAll()).thenReturn(allDrivers);

        List<Driver> result = driverService.findBy("", "");

        assertNotNull(result);
        assertEquals(4, result.size());
        assertEquals(allDrivers.get(0).getId(), result.get(0).getId());
        assertEquals(allDrivers.get(1).getId(), result.get(1).getId());
        assertEquals(allDrivers.get(2).getId(), result.get(2).getId());
        assertEquals(allDrivers.get(3).getId(), result.get(3).getId());

        verify(driverRepository, times(0)).findByCity(anyString());
        verify(driverRepository, times(0)).findByName(anyString());
        verify(driverRepository, times(0)).findByNameAndCity(anyString(), anyString());
    }

    @Test
    void whenNameIsGivenAndCityIsNull_findBy_returnsDriversByName() {
        String name = "Mary";
        List<Driver> allDrivers = getDrivers();
        when(driverRepository.findByName(name))
                .thenReturn(allDrivers.stream()
                        .filter(d -> name.equals(d.getName()))
                        .toList());

        List<Driver> result = driverService.findBy(name, null);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(2L, result.get(0).getId());
        assertEquals(3L, result.get(1).getId());

        verify(driverRepository, times(0)).findAll();
        verify(driverRepository, times(0)).findByCity(anyString());
        verify(driverRepository, times(0)).findByNameAndCity(anyString(), anyString());
    }

    @Test
    void whenNameIsGivenAndCityIsEmpty_findBy_returnsDriversByName() {
        String name = "Mary";
        List<Driver> allDrivers = getDrivers();
        when(driverRepository.findByName(name))
                .thenReturn(allDrivers.stream()
                        .filter(d -> name.equals(d.getName()))
                        .toList());

        List<Driver> result = driverService.findBy(name, "");

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(2L, result.get(0).getId());
        assertEquals(3L, result.get(1).getId());

        verify(driverRepository, times(0)).findAll();
        verify(driverRepository, times(0)).findByCity(anyString());
        verify(driverRepository, times(0)).findByNameAndCity(anyString(), anyString());
    }

    @Test
    void whenNameIsNullAndCityIsGiven_findBy_returnsDriversByCity() {
        String city = "London";
        List<Driver> allDrivers = getDrivers();
        when(driverRepository.findByCity(city))
                .thenReturn(allDrivers.stream()
                        .filter(d -> city.equals(d.getCity()))
                        .toList());

        List<Driver> result = driverService.findBy(null, city);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(2L, result.get(0).getId());
        assertEquals(4L, result.get(1).getId());

        verify(driverRepository, times(0)).findAll();
        verify(driverRepository, times(0)).findByName(anyString());
        verify(driverRepository, times(0)).findByNameAndCity(anyString(), anyString());
    }

    @Test
    void whenNameIsEmptyAndCityIsGiven_findBy_returnsDriversByCity() {
        String city = "London";
        List<Driver> allDrivers = getDrivers();
        when(driverRepository.findByCity(city))
                .thenReturn(allDrivers.stream()
                        .filter(d -> city.equals(d.getCity()))
                        .toList());

        List<Driver> result = driverService.findBy("", city);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(2L, result.get(0).getId());
        assertEquals(4L, result.get(1).getId());

        verify(driverRepository, times(0)).findAll();
        verify(driverRepository, times(0)).findByName(anyString());
        verify(driverRepository, times(0)).findByNameAndCity(anyString(), anyString());
    }

    @Test
    void whenNameAndCityAreGiven_findBy_returnsDriversByNameAndCity() {
        String city = "London";
        String name = "Mary";
        List<Driver> allDrivers = getDrivers();
        when(driverRepository.findByNameAndCity(name, city))
                .thenReturn(allDrivers.stream()
                        .filter(d -> name.equals(d.getName()) && city.equals(d.getCity()))
                        .toList());

        List<Driver> result = driverService.findBy(name, city);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(2L, result.get(0).getId());

        verify(driverRepository, times(0)).findAll();
        verify(driverRepository, times(0)).findByName(anyString());
        verify(driverRepository, times(0)).findByCity(anyString());
    }

    private static List<Driver> getDrivers() {
        Driver driver1 = new Driver(1L, "John", "john@gmail.com", "Bucharest");
        Driver driver2 = new Driver(2L, "Mary", "mary@gmail.com", "London");
        Driver driver3 = new Driver(3L, "Mary", "mary@gmail.com", "Edinburgh");
        Driver driver4 = new Driver(4L, "Lili", "mary@gmail.com", "London");
        return List.of(driver1, driver2, driver3, driver4);
    }

}