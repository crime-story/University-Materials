package com.unibuc.mockexam.controller;

import com.unibuc.mockexam.dto.CreateDriverDto;
import com.unibuc.mockexam.dto.UpdateDriverDto;
import com.unibuc.mockexam.mapper.DriverMapper;
import com.unibuc.mockexam.model.Driver;
import com.unibuc.mockexam.service.DriverService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/drivers")
public class DriverController {

    private DriverService driverService;
    private DriverMapper driverMapper;

    public DriverController(DriverService driverService, DriverMapper driverMapper) {
        this.driverService = driverService;
        this.driverMapper = driverMapper;
    }

    @PostMapping
    public ResponseEntity<Driver> create(
            @RequestBody
            @Valid
            CreateDriverDto createDriverDto) {
        Driver driver = driverMapper.toDriver(createDriverDto);
        Driver createdDriver = driverService.create(driver);
        return ResponseEntity.created(URI.create("/drivers" + createdDriver.getId()))
                .body(createdDriver);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Driver> update(
            @PathVariable
            Long id,

            @RequestBody
            @Valid
            UpdateDriverDto updateDriverDto) {
        if (!id.equals(updateDriverDto.getId())) {
            throw new RuntimeException("Id from path does not match with id from request");
        }

        Driver driver = driverMapper.toDriver(updateDriverDto);
        return ResponseEntity.ok()
                .body(driverService.update(driver));
    }


    @GetMapping
    public List<Driver> find(
            @RequestParam(required = false)
            String name,
            @RequestParam(required = false)
            String city) {
        return driverService.findBy(name, city);
    }


}
