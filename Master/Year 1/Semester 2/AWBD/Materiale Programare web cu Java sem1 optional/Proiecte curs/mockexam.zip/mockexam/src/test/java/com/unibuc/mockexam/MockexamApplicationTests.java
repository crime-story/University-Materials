package com.unibuc.mockexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
