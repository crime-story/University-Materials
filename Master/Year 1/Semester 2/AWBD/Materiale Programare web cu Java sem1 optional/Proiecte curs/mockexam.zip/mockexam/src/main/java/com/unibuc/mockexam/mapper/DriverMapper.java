package com.unibuc.mockexam.mapper;

import com.unibuc.mockexam.dto.CreateDriverDto;
import com.unibuc.mockexam.dto.UpdateDriverDto;
import com.unibuc.mockexam.model.Driver;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DriverMapper {

    Driver toDriver(CreateDriverDto createDriverDto);

    Driver toDriver(UpdateDriverDto updateDriverDto);

}
