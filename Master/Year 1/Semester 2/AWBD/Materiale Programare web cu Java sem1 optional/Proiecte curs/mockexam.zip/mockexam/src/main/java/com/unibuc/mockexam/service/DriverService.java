package com.unibuc.mockexam.service;

import com.unibuc.mockexam.exception.DriverAlreadyExistsException;
import com.unibuc.mockexam.model.Driver;
import com.unibuc.mockexam.repository.DriverRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DriverService {

    private DriverRepository driverRepository;

    public DriverService(DriverRepository driverRepository) {
        this.driverRepository = driverRepository;
    }

    public Driver create(Driver driver) {
        Optional<Driver> otherDriverSameEmail = driverRepository.findByEmail(driver.getEmail());
        if(otherDriverSameEmail.isPresent()) {
            throw new DriverAlreadyExistsException("Driver already exists");
        }
        return driverRepository.save(driver);
    }

    public Driver update(Driver driver) {
        Optional<Driver> otherDriverSameEmail = driverRepository.findByEmailAndIdNot(driver.getEmail(), driver.getId());
        if(otherDriverSameEmail.isPresent()) {
            throw new DriverAlreadyExistsException("Another driver has the same email.");
        }
        return driverRepository.save(driver);
    }

    public List<Driver> findBy(String name, String city) {
        if(name == null || name.isEmpty()) {
            if(city == null || city.isEmpty()) {
                return driverRepository.findAll();
            } else {
                return driverRepository.findByCity(city);
            }
        } else {
            if(city == null || city.isEmpty()) {
                return driverRepository.findByName(name);
            } else {
                return driverRepository.findByNameAndCity(name, city);
            }
        }
    }
}
