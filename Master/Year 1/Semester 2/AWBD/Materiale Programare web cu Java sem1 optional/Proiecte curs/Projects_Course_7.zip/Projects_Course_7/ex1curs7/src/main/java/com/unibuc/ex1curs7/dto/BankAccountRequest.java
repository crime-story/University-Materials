package com.unibuc.ex1curs7.dto;

import com.unibuc.ex1curs7.model.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class BankAccountRequest {

    @NotBlank(message = "Account number must not be null and must not be empty")
    private String accountNumber;

    @NotNull(message = "Balance must not be null")
    @Min(value = 0, message = "Balance must be a positive value")
    private Double balance;

    @NotNull(message = "Bank account type must not be null")
    private BankAccountType type;

    @NotBlank
    @Pattern(regexp = com.unibuc.ex1curs7.model.Pattern.VISA_CREDIT_CARD, message = "Invalid card number")
    private String cardNumber;

    public BankAccountRequest() {
    }

    public BankAccountRequest(String accountNumber,
                              double balance, BankAccountType type, String cardNumber) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.type = type;
        this.cardNumber = cardNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public BankAccountType getType() {
        return type;
    }

    public void setType(BankAccountType type) {
        this.type = type;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }
}
