package com.unibuc.ex1curs7.model;

public enum BankAccountType {
    DEBIT, SAVINGS
}
