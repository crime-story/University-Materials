package com.unibuc.ex1curs12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1Curs12Application {

    public static void main(String[] args) {
        SpringApplication.run(Ex1Curs12Application.class, args);
    }

}
