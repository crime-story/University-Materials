package com.example.ex1curs9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1curs9Application {

    public static void main(String[] args) {
        SpringApplication.run(Ex1curs9Application.class, args);
    }

}
