package com.unibuc.ex1curs4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex1Curs4Application {

    public static void main(String[] args) {
        SpringApplication.run(Ex1Curs4Application.class, args);
    }

}
