package com.unibuc.ex1curs4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1curs4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
