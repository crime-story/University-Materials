package com.unibuc.ex1curs10.model;

public class Pattern {
    public static final String VISA_CREDIT_CARD = "^4[0-9]{12}(?:[0-9]{3})?$";
}
