import { MarksPipe } from './marks.pipe';

describe('MarksPipe', () => {
  it('create an instance', () => {
    const pipe = new MarksPipe();
    expect(pipe).toBeTruthy();
  });
});
