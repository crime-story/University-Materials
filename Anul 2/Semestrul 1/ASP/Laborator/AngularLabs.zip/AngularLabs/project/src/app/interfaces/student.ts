export interface Student {
  id: number;
  age: number;
  name: string;
}
