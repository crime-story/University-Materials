import { HoverBtnDirective } from './hover-btn.directive';

describe('HoverBtnDirective', () => {
  it('should create an instance', () => {
    const directive = new HoverBtnDirective();
    expect(directive).toBeTruthy();
  });
});
